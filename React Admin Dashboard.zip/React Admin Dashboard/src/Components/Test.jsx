import { useEffect, useState } from "react";
import dayjs from "dayjs";
import locale from "dayjs/locale/en";
import weekdayPlugin from "dayjs/plugin/weekday";
import objectPlugin from "dayjs/plugin/toObject";
import isTodayPlugin from "dayjs/plugin/isToday";



  //calendar

const Calendar = () => {
	const now = dayjs().locale({
		...locale,
	});

	dayjs.extend(weekdayPlugin);
	dayjs.extend(objectPlugin);
	dayjs.extend(isTodayPlugin);

	const [currentMonth, setCurrentMonth] = useState(now);
	const [arrayOfDays, setArrayOfDays] = useState([]);

	console.log('arrayOfDays:', arrayOfDays);




	const getAllDays = () => {
		let currentDate = currentMonth.startOf("month").weekday(0);
		const nextMonth = currentMonth.add(1, "month").month();

		let allDates = [];
		let weekDates = [];

		let weekCounter = 1;

		while (currentDate.weekday(0).toObject().months !== nextMonth) {
			const formated = formateDateObject(currentDate);

			weekDates.push(formated);

			if (weekCounter === 7) {
				allDates.push({ dates: weekDates });
				weekDates = [];
				weekCounter = 0;
			}

			weekCounter++;
			currentDate = currentDate.add(1, "day");
		}
		console.log(allDates)
		setArrayOfDays(allDates);
	};

	useEffect(() => {
		getAllDays();
	}, [currentMonth]);

	const renderCells = () => {
		const rows = [];
		let days = [];

		arrayOfDays.forEach((week, index) => {
			week.dates.forEach((d, i) => {
				days.push(
					<div
						className={`col cell ${
							!d.isCurrentMonth ? "disabled" : d.isCurrentDay ? "selected" : ""
						}`}
						key={i}
					>
						<span className="number">{d.day}</span>
						
            <div className="todays">
				<div className="todaysItem">
					<ul className="itemlist">
					<li className="item1">To Do Item 1{ d.day}</li>
					<li className="item2">To Do item 2</li>
					</ul>
				</div>
             {/* <a href="https://www.youtube.com/watch?v=CgCPP2KO5ds" target="_blank" ><span className="checkIn">|  100  |</span> </a>
            <a href="https://www.linkedin.com/feed/" target="_blank"><span className="paid">|  155  |</span> </a> 
            <a href ="https://chat.openai.com/c/25e62409-0ae1-486a-aab9-891451b2a17c" target="_blank"><span className="unPaid">|  145  |</span>   </a>  */}
            </div>
						<span className="bg">{d.day}</span>
					</div>
				);
			});
			rows.push(
				<div className="row" key={index}>
					{days}
				</div>
			);
			days = [];
		});

		return <div className="body">{rows}</div>;
	};

	const formateDateObject = date => {
		const clonedObject = { ...date.toObject() };

		const formatedObject = {
			day: clonedObject.date,
			month: clonedObject.months,
			year: clonedObject.years,
			isCurrentMonth: clonedObject.months === currentMonth.month(),
			isCurrentDay: date.isToday(),
		};

		return formatedObject;
	};

	
	
	return (
		<div className="calendar">
			{renderHeader()}
			{renderDays()}
			{renderCells()}
			
		</div>
		


		
	);
};

export default Calendar;