//components
import "./App.css";
import Calendar from "./Components/Calendar";
//styles


const App = () => {
  return (
    <div className="App">
      <Calendar />
    </div>
  );
}

export default App;