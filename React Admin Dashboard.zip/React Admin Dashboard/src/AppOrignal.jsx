import { useState } from 'react'
import './AppOrignal.css'    //  here it will give white background otherwise comeback to black
import Header from './Header'
import Sidebar from './Sidebar'
import Home from './Home'
import AppRoutes from './AppRoutes'




function App() {
  const [openSidebarToggle, setOpenSidebarToggle] = useState(false)

  const OpenSidebar = () => {
    setOpenSidebarToggle(!openSidebarToggle)
  }

  return (
    <div className='grid-container'>
      <Header OpenSidebar={OpenSidebar}/>
      <Sidebar openSidebarToggle={openSidebarToggle} OpenSidebar={OpenSidebar}/>
      <AppRoutes />
    
      
    </div>


  )
}

export default App
