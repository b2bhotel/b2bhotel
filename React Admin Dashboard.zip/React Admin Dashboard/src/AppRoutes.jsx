import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "../src/Home";
//  import Calendar from "../src/Components/Calendar";
import Calendar from "../src/App";



function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />}></Route>
      <Route path="/calendar" element={<Calendar />}></Route>
    
    </Routes>
  );
}
export default AppRoutes;